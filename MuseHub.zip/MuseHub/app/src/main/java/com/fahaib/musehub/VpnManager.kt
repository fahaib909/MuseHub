package com.fahaib.musehub

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.Interface
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

enum class VpnStatus { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

/**
 * Runs a WireGuard tunnel that carries ONLY this app's traffic.
 * Every *.conf file inside assets/configs/ is a server. They are tried one by one
 * until one of them really has working internet.
 */
object VpnManager {
    val status = MutableStateFlow(VpnStatus.DISCONNECTED)
    val message = MutableStateFlow<String?>(null)

    private var backend: GoBackend? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val tunnel = object : Tunnel {
        override fun getName() = "musehub"
        override fun onStateChange(newState: Tunnel.State) {
            // Only react if the tunnel dies after we were connected (e.g. revoked by the system).
            if (newState != Tunnel.State.UP && status.value == VpnStatus.CONNECTED) {
                status.value = VpnStatus.DISCONNECTED
            }
        }
    }

    private fun backend(ctx: Context): GoBackend =
        backend ?: GoBackend(ctx.applicationContext).also { backend = it }

    private fun configNames(ctx: Context): List<String> =
        (ctx.assets.list("configs") ?: emptyArray()).filter { it.endsWith(".conf") }.sorted()

    private fun buildConfig(ctx: Context, name: String): Config {
        val parsed = ctx.assets.open("configs/$name").use { Config.parse(it) }
        val src = parsed.`interface`
        val iface = Interface.Builder()
            .addAddresses(src.addresses)
            .addDnsServers(src.dnsServers)
            .setKeyPair(src.keyPair)
            .includeApplication(ctx.packageName) // per-app VPN: only Muse Hub uses the tunnel
            .build()
        return Config.Builder().setInterface(iface).addPeers(parsed.peers).build()
    }

    private suspend fun hasInternet(): Boolean {
        repeat(3) {
            try {
                val c = URL("https://www.gstatic.com/generate_204").openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 6000
                val code = c.responseCode
                c.disconnect()
                if (code in 200..299) return true
            } catch (_: Exception) {
            }
            delay(1000)
        }
        return false
    }

    fun connect(ctx: Context) {
        if (status.value == VpnStatus.CONNECTED || status.value == VpnStatus.CONNECTING) return
        status.value = VpnStatus.CONNECTING
        message.value = null
        val appCtx = ctx.applicationContext
        scope.launch {
            val names = configNames(appCtx)
            if (names.isEmpty()) {
                message.value = "Koi config nahi mili (assets/configs)"
                status.value = VpnStatus.ERROR
                return@launch
            }
            val problems = mutableListOf<String>()
            for (name in names) {
                try {
                    backend(appCtx).setState(tunnel, Tunnel.State.UP, buildConfig(appCtx, name))
                    if (hasInternet()) {
                        message.value = "Server: ${name.removeSuffix(".conf")}"
                        status.value = VpnStatus.CONNECTED
                        return@launch
                    }
                    problems += "${name.removeSuffix(".conf")}: internet nahi chala"
                } catch (e: Exception) {
                    problems += "${name.removeSuffix(".conf")}: ${e.message ?: e.javaClass.simpleName}"
                }
                try {
                    backend(appCtx).setState(tunnel, Tunnel.State.DOWN, null)
                } catch (_: Exception) {
                }
            }
            message.value = problems.joinToString("\n")
            status.value = VpnStatus.ERROR
        }
    }

    fun disconnect(ctx: Context) {
        val appCtx = ctx.applicationContext
        scope.launch {
            try {
                backend(appCtx).setState(tunnel, Tunnel.State.DOWN, null)
            } catch (_: Exception) {
            }
            status.value = VpnStatus.DISCONNECTED
        }
    }

    fun setError(msg: String) {
        message.value = msg
        status.value = VpnStatus.ERROR
    }
}
