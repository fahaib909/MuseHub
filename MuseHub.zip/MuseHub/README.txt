MUSE HUB - build karne ka tareeqa
1. Android Studio (Koala ya naya) install karo.
2. File > Open > MuseHub folder chuno. Gradle sync hone do (internet chahiye).
3. Phone USB debugging ke saath lagao ya Build > Build APK(s) karo.
4. Pehli baar app khulne par "VPN permission" popup aayega, Allow karo.

Zaroori note:
- Website address: app/src/main/java/com/fahaib/musehub/AccountStore.kt mein DEFAULT_URL badlo
  (ya app mein account ke menu se Rename/edit karke address daalo).
- VPN config: app/src/main/assets/configs/ (har .conf file ek server hai, app ek ek karke try karti hai). Is mein tumhari private key hai, project kisi ko share mat karna.
- Free Proton server kabhi slow/band ho sakta hai. Naya config download karke wg.conf replace kar do.

Servers: app mein "Servers" button se list, har server ka ms, test, select aur naya config paste kar sakte ho.
Agar sab servers fail hon to Servers screen ke neeche wala log screenshot bhejo.
