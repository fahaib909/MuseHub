package com.fahaib.musehub

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.Interface
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

enum class VpnStatus { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

/**
 * Runs a WireGuard tunnel (config from assets/wg.conf) that carries ONLY this app's traffic.
 * Every other app on the phone keeps using the normal internet.
 */
object VpnManager {
    val status = MutableStateFlow(VpnStatus.DISCONNECTED)
    val message = MutableStateFlow<String?>(null)

    private var backend: GoBackend? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val tunnel = object : Tunnel {
        override fun getName() = "musehub"
        override fun onStateChange(newState: Tunnel.State) {
            if (newState == Tunnel.State.UP) {
                status.value = VpnStatus.CONNECTED
            } else if (status.value != VpnStatus.CONNECTING && status.value != VpnStatus.ERROR) {
                status.value = VpnStatus.DISCONNECTED
            }
        }
    }

    private fun backend(ctx: Context): GoBackend =
        backend ?: GoBackend(ctx.applicationContext).also { backend = it }

    private fun buildConfig(ctx: Context): Config {
        val parsed = ctx.assets.open("wg.conf").use { Config.parse(it) }
        val src = parsed.`interface`
        val iface = Interface.Builder()
            .addAddresses(src.addresses)
            .addDnsServers(src.dnsServers)
            .setKeyPair(src.keyPair)
            .includeApplication(ctx.packageName) // per-app VPN: only Muse Hub goes through the tunnel
            .build()
        return Config.Builder().setInterface(iface).addPeers(parsed.peers).build()
    }

    fun connect(ctx: Context) {
        if (status.value == VpnStatus.CONNECTED || status.value == VpnStatus.CONNECTING) return
        status.value = VpnStatus.CONNECTING
        message.value = null
        val appCtx = ctx.applicationContext
        scope.launch {
            try {
                backend(appCtx).setState(tunnel, Tunnel.State.UP, buildConfig(appCtx))
                status.value = VpnStatus.CONNECTED
            } catch (e: Exception) {
                message.value = e.message ?: e.javaClass.simpleName
                status.value = VpnStatus.ERROR
            }
        }
    }

    fun disconnect(ctx: Context) {
        val appCtx = ctx.applicationContext
        scope.launch {
            try {
                backend(appCtx).setState(tunnel, Tunnel.State.DOWN, null)
            } catch (_: Exception) {
            }
            status.value = VpnStatus.DISCONNECTED
        }
    }

    fun setError(msg: String) {
        message.value = msg
        status.value = VpnStatus.ERROR
    }
}
