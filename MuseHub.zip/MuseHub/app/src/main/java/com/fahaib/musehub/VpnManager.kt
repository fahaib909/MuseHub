package com.fahaib.musehub

import android.content.Context
import android.content.SharedPreferences
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.InetEndpoint
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException

enum class VpnStatus { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class Server(val id: String, val name: String, val text: String, val custom: Boolean)

/** ms == null means the test failed; note says why. */
data class ServerResult(val ms: Int?, val note: String)

/**
 * WireGuard tunnel that carries ONLY this app's traffic.
 * Servers = assets/configs/*.conf (built in) + configs pasted inside the app.
 */
object VpnManager {
    const val AUTO = "auto"
    private val FALLBACK_PORTS = listOf(443, 88)

    val status = MutableStateFlow(VpnStatus.DISCONNECTED)
    val message = MutableStateFlow<String?>(null)
    val servers = MutableStateFlow<List<Server>>(emptyList())
    val results = MutableStateFlow<Map<String, ServerResult>>(emptyMap())
    val selected = MutableStateFlow(AUTO)
    val activeName = MutableStateFlow<String?>(null)
    val activeMs = MutableStateFlow<Int?>(null)
    val log = MutableStateFlow<List<String>>(emptyList())
    val testing = MutableStateFlow(false)

    private var backend: GoBackend? = null
    private var job: Job? = null
    private var inited = false
    private lateinit var prefs: SharedPreferences
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val tunnel = object : Tunnel {
        override fun getName() = "musehub"
        override fun onStateChange(newState: Tunnel.State) {
            if (newState != Tunnel.State.UP && status.value == VpnStatus.CONNECTED) {
                status.value = VpnStatus.DISCONNECTED
            }
        }
    }

    private fun backend(ctx: Context): GoBackend =
        backend ?: GoBackend(ctx.applicationContext).also { backend = it }

    private fun addLog(line: String) {
        log.value = (log.value + line).takeLast(40)
    }

    // ---------- servers ----------

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("vpn", Context.MODE_PRIVATE)
        selected.value = prefs.getString("selected", AUTO) ?: AUTO
        reloadServers(app)
        prefs.getString("results", null)?.let { raw ->
            try {
                val o = JSONObject(raw)
                val m = mutableMapOf<String, ServerResult>()
                for (k in o.keys()) {
                    val r = o.getJSONObject(k)
                    m[k] = ServerResult(if (r.has("ms")) r.getInt("ms") else null, r.optString("note"))
                }
                results.value = m
            } catch (_: Exception) {
            }
        }
    }

    private fun serverName(text: String, fallback: String): String =
        text.substringAfter("[Peer]", "").lines().map { it.trim() }
            .firstOrNull { it.startsWith("#") }
            ?.removePrefix("#")?.trim()?.takeIf { it.isNotEmpty() } ?: fallback

    private fun reloadServers(app: Context) {
        val list = mutableListOf<Server>()
        (app.assets.list("configs") ?: emptyArray()).filter { it.endsWith(".conf") }.forEach { f ->
            val id = f.removeSuffix(".conf")
            val text = app.assets.open("configs/$f").bufferedReader().use { it.readText() }
            list += Server(id, serverName(text, id), text, false)
        }
        list.sortBy { it.name.filter(Char::isDigit).toIntOrNull() ?: 0 }
        val raw = prefs.getString("custom", null)
        if (raw != null) {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list += Server(o.getString("id"), o.getString("name"), o.getString("text"), true)
            }
        }
        servers.value = list
    }

    /** Returns an error message, or null when saved. */
    fun addServer(ctx: Context, text: String): String? {
        val t = text.trim()
        try {
            Config.parse(BufferedReader(StringReader(t)))
        } catch (e: Exception) {
            return "Config sahi nahi: ${e.message}"
        }
        val name = serverName(t, "Custom ${servers.value.count { it.custom } + 1}")
        val arr = JSONArray(prefs.getString("custom", "[]"))
        arr.put(JSONObject().put("id", "c" + System.currentTimeMillis()).put("name", name).put("text", t))
        prefs.edit().putString("custom", arr.toString()).apply()
        reloadServers(ctx.applicationContext)
        return null
    }

    fun removeServer(ctx: Context, id: String) {
        val arr = JSONArray(prefs.getString("custom", "[]"))
        val keep = JSONArray()
        for (i in 0 until arr.length()) {
            if (arr.getJSONObject(i).getString("id") != id) keep.put(arr.getJSONObject(i))
        }
        prefs.edit().putString("custom", keep.toString()).apply()
        reloadServers(ctx.applicationContext)
        if (selected.value == id) select(ctx, AUTO)
    }

    // ---------- connecting ----------

    private fun buildConfig(ctx: Context, server: Server, port: Int?): Config {
        val parsed = Config.parse(BufferedReader(StringReader(server.text)))
        val src = parsed.`interface`
        val iface = Interface.Builder()
            .addAddresses(src.addresses)
            .addDnsServers(src.dnsServers)
            .setKeyPair(src.keyPair)
            .includeApplication(ctx.packageName) // per-app VPN
            .build()
        val peers = parsed.peers.map { p ->
            val ep = p.endpoint.orElse(null)
            if (port == null || ep == null) {
                p
            } else {
                val host = if (ep.host.contains(":")) "[${ep.host}]" else ep.host
                Peer.Builder()
                    .setPublicKey(p.publicKey)
                    .addAllowedIps(p.allowedIps)
                    .setPersistentKeepalive(p.persistentKeepalive.orElse(25))
                    .setEndpoint(InetEndpoint.parse("$host:$port"))
                    .build()
            }
        }
        return Config.Builder().setInterface(iface).addPeers(peers).build()
    }

    private fun handshakeDone(ctx: Context): Boolean = try {
        val stats = backend(ctx).getStatistics(tunnel)
        stats.peers().any { (stats.peer(it)?.latestHandshakeEpochMillis() ?: 0L) > 0L }
    } catch (_: Exception) {
        false
    }

    private fun httpPing(): Pair<Int?, String> {
        var why = ""
        repeat(2) {
            val t = System.currentTimeMillis()
            try {
                val c = URL("http://connectivitycheck.gstatic.com/generate_204").openConnection() as HttpURLConnection
                c.connectTimeout = 5000
                c.readTimeout = 5000
                c.useCaches = false
                val code = c.responseCode
                c.disconnect()
                if (code in 200..299) return Pair((System.currentTimeMillis() - t).toInt(), "ok")
                why = "HTTP $code"
            } catch (e: UnknownHostException) {
                why = "DNS nahi chala"
            } catch (e: Exception) {
                why = e.javaClass.simpleName
            }
        }
        return Pair(null, why)
    }

    private fun downQuiet(ctx: Context) {
        try {
            backend(ctx).setState(tunnel, Tunnel.State.DOWN, null)
        } catch (_: Exception) {
        }
    }

    private suspend fun attempt(ctx: Context, server: Server, port: Int?): ServerResult {
        val label = server.name + (port?.let { " (port $it)" } ?: "")
        message.value = "Try: $label"
        addLog("-> $label")
        try {
            backend(ctx).setState(tunnel, Tunnel.State.UP, buildConfig(ctx, server, port))
        } catch (e: Exception) {
            val n = "start nahi hua: ${e.message ?: e.javaClass.simpleName}"
            addLog("x $n")
            return ServerResult(null, n)
        }
        val t0 = System.currentTimeMillis()
        var hs = false
        while (System.currentTimeMillis() - t0 < 6000) {
            hs = handshakeDone(ctx)
            if (hs) break
            delay(250)
        }
        if (!hs) {
            addLog("x handshake nahi hua")
            return ServerResult(null, "handshake nahi hua (server band ya network WireGuard block kar raha hai)")
        }
        val (ms, why) = httpPing()
        return if (ms != null) {
            addLog("ok ${ms} ms")
            ServerResult(ms, "ok")
        } else {
            addLog("x handshake ok, internet nahi: $why")
            ServerResult(null, "handshake ok par internet nahi ($why)")
        }
    }

    private fun record(s: Server, r: ServerResult) {
        results.value = results.value + (s.id to r)
        val o = JSONObject()
        results.value.forEach { (k, v) ->
            val j = JSONObject()
            v.ms?.let { j.put("ms", it) }
            j.put("note", v.note)
            o.put(k, j)
        }
        prefs.edit().putString("results", o.toString()).apply()
    }

    private fun ordered(all: List<Server>): List<Server> {
        val last = prefs.getString("lastGood", null)
        val res = results.value
        return all.sortedWith(
            compareBy<Server>(
                { if (it.id == last) 0 else 1 },
                { val r = res[it.id]; if (r == null) 1 else if (r.ms != null) 0 else 2 },
                { res[it.id]?.ms ?: Int.MAX_VALUE }
            )
        )
    }

    private suspend fun runConnect(app: Context) {
        status.value = VpnStatus.CONNECTING
        message.value = null
        activeName.value = null
        activeMs.value = null
        val all = servers.value
        if (all.isEmpty()) {
            message.value = "Koi server nahi hai"
            status.value = VpnStatus.ERROR
            return
        }
        val chosen = if (selected.value != AUTO) all.firstOrNull { it.id == selected.value } else null
        val candidates = if (chosen != null) listOf(chosen) else ordered(all)
        val ports: List<Int?> = listOf<Int?>(null) + FALLBACK_PORTS
        for (port in ports) {
            for (s in candidates) {
                currentCoroutineContext().ensureActive()
                val r = attempt(app, s, port)
                if (r.ms != null || port == null) record(s, r)
                if (r.ms != null) {
                    prefs.edit().putString("lastGood", s.id).apply()
                    activeName.value = s.name
                    activeMs.value = r.ms
                    message.value = null
                    status.value = VpnStatus.CONNECTED
                    return
                }
                downQuiet(app)
            }
        }
        message.value = "Koi server nahi chala. Servers screen mein har server ki wajah dekho."
        status.value = VpnStatus.ERROR
    }

    private fun launchJob(block: suspend () -> Unit) {
        val old = job
        job = scope.launch {
            old?.cancelAndJoin()
            block()
        }
    }

    fun connect(ctx: Context) {
        if (status.value == VpnStatus.CONNECTED || status.value == VpnStatus.CONNECTING) return
        val app = ctx.applicationContext
        launchJob { runConnect(app) }
    }

    fun select(ctx: Context, id: String) {
        val app = ctx.applicationContext
        selected.value = id
        prefs.edit().putString("selected", id).apply()
        launchJob {
            downQuiet(app)
            runConnect(app)
        }
    }

    fun testAll(ctx: Context) {
        if (testing.value) return
        val app = ctx.applicationContext
        launchJob {
            testing.value = true
            try {
                status.value = VpnStatus.CONNECTING
                downQuiet(app)
                for (s in servers.value) {
                    currentCoroutineContext().ensureActive()
                    message.value = "Test: ${s.name}"
                    record(s, attempt(app, s, null))
                    downQuiet(app)
                }
            } finally {
                testing.value = false
            }
            runConnect(app)
        }
    }

    fun cancel(ctx: Context) {
        val app = ctx.applicationContext
        val old = job
        job = scope.launch {
            old?.cancelAndJoin()
            testing.value = false
            downQuiet(app)
            status.value = VpnStatus.DISCONNECTED
            message.value = null
        }
    }

    fun disconnect(ctx: Context) = cancel(ctx)

    fun setError(msg: String) {
        message.value = msg
        status.value = VpnStatus.ERROR
    }
}
